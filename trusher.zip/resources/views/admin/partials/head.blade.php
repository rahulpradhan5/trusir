<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modernize Free</title>
    <link rel="shortcut icon" type="image/png" href="../assets/images/logos/favicon.png" />
    <link rel="stylesheet" href="../assets/css/styles.min.css" />
    <!-- <link rel="stylesheet" href="../css/style.css" /> -->
    <script src="../assets/js/jquery.js"></script>
</head>
<style>
    .p-active{
        color: blue !important;
        text-decoration: underline;

    }
</style>