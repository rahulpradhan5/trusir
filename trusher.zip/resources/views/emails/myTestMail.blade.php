<html>
    <body>
        <h1>Hello, {{ $name }}!</h1>
        <p>{{ $body }}</p>
    </body>
</html>
