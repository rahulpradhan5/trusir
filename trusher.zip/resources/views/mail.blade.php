
<table >
    <tr>
        <td>{{$name}}</td>
        <td>{{$email}}</td>
        <td>{{$content}}</td>
    </tr>
</table>