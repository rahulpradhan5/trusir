<?php

$count = $students->count();

if ($count <= 0) {
?>
    <tr>
        <td class="border-bottom-0" style="display: flex;gap:5px;align-items:center;">
            <img src="assets/images/products/sad.svg" alt="" style="height:20px;width:20px;"> No data found
        </td>
    </tr>
    <?php
} else {
    for ($i = 0; $i <= $count - 1; $i++) {
    ?>
        <tr id="studnet<?php echo e($students[$i]->id); ?>">
            <td class="border-bottom-0">
                <h6 class="fw-semibold mb-0"><?php echo e($i + 1); ?></h6>
            </td>
            <td class="border-bottom-0">
                <h6 class="fw-semibold mb-1"><?php echo e($students[$i]->name); ?></h6>
            </td>
            <td class="border-bottom-0">
                <p class="mb-0 fw-normal"><?php echo e($students[$i]->phone); ?></p>
            </td>
            <td class="border-bottom-0">
                <p class="mb-0 fw-normal">Class <?php echo e($students[$i]->class); ?></p>
            </td>
            <td class="border-bottom-0 d-flex align-items-center gap-2">
                <div class="d-flex align-items-center gap-2">
                    <a href="/admin/view-student?id=<?php echo e($students[$i]->id); ?>"><button class="btn btn-primary btn-sm">View</button></a>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <a href="/admin/edit-student?id=<?php echo e($students[$i]->id); ?>"><button class="btn btn-success btn-sm">Edit</button></a>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <button class="btn btn-danger btn-sm" id="delete<?php echo e($students[$i]->id); ?>" onclick="delete('<?php echo e($students[$i]->id); ?>','studnet<?php echo e($students[$i]->id); ?>')">Delete</button>
                </div>
            </td>

        </tr>
<?php
    }
}
?><?php /**PATH E:\laravel\trusher\resources\views/admin/student/search/index.blade.php ENDPATH**/ ?>