<?php
if (isset($me)) {
    foreach ($gk as $gks) {
?>
        <!-- post card -->
        <div class="post-card flex gap10 " id="gkd<?php echo e($gks->id); ?>">
            <!-- post-image -->
            <?php
            if ($gks->image != "") {
            ?>
                <div class="post-img">
                    <img src="<?php echo e($gks->image); ?>" alt="">
                </div>

            <?php
            }
            ?>
            <!-- cancel -->
            <?php
            if ($gks->teacher_id == Session()->get('user_id') && Session()->get('role') == 'teacher') {
            ?>
                <div class="cancel" onclick="deleteCate('<?php echo e($gks->id); ?>')">
                    <img src="images/cancel-red.svg" alt="">
                </div>
            <?php
            }
            ?>
            <!-- post-content -->
            <div class="content flex-colomn gap10">
                <h3><?php echo e($gks->tittle); ?></h3>
                <div class="flex-colomn">
                    <div class="flex gap10 align-center">
                        <?php
                        if (Session()->get('role') == 'student' && Session()->get('user_id') == $gks->student_id) {
                        ?>
                            <span class="tag">For you</span>
                        <?php
                        }
                        ?>
                        <span class="tag"><?php echo e($gks->category); ?></span>
                    </div>
                    <span>Posted at: <?php echo e($gks->dt); ?></span>
                </div>
                <p class="p-primary expand" id="desc<?php echo e($gks->id); ?>"><?php echo e($gks->disc); ?></p>
                <span class="read-more width100" id="gk<?php echo e($gks->id); ?>" onclick="readmore('gk<?php echo e($gks->id); ?>','desc<?php echo e($gks->id); ?>')">Read more</span>
            </div>
        </div>
    <?php
    }
} else if (isset($loadmore)) {
    foreach ($gk as $gks) {
    ?>
        <!-- post card -->
        <div class="post-card flex gap10 " id="gkd<?php echo e($gks->id); ?>">
            <!-- post-image -->
            <?php
            if ($gks->image != "") {
            ?>
                <div class="post-img">
                    <img src="<?php echo e($gks->image); ?>" alt="">
                </div>

            <?php
            }
            ?>
            <!-- cancel -->
            <?php
            if ($gks->teacher_id == Session()->get('user_id') && Session()->get('role') == 'teacher') {
            ?>
                <div class="cancel" onclick="deleteCate('<?php echo e($gks->id); ?>')">
                    <img src="images/cancel-red.svg" alt="">
                </div>
            <?php
            }
            ?>
            <!-- post-content -->
            <div class="content flex-colomn gap10">
                <h3><?php echo e($gks->tittle); ?></h3>
                <div class="flex-colomn">
                    <div class="flex gap10 align-center">
                        <?php
                        if (Session()->get('role') == 'student' && Session()->get('user_id') == $gks->student_id) {
                        ?>
                            <span class="tag">For you</span>
                        <?php
                        }
                        ?>
                        <span class="tag"><?php echo e($gks->category); ?></span>
                    </div>
                    <span>Posted at: <?php echo e($gks->dt); ?></span>
                </div>
                <p class="p-primary expand" id="desc<?php echo e($gks->id); ?>"><?php echo e($gks->disc); ?></p>
                <span class="read-more width100" id="gk<?php echo e($gks->id); ?>" onclick="readmore('gk<?php echo e($gks->id); ?>','desc<?php echo e($gks->id); ?>')">Read more</span>
            </div>
        </div>
    <?php
    } ?>
    <?php
    if ($gk->count() == 0) {
        $id = 0;
    } else if ($gk->count() - 1 < 0) {
        $id = $gk[$gk->count()]->id;
    } else {
        $id =  $gk[$gk->count() - 1]->id;
    }

    ?>
    <input type="hidden" id="contentId" value="<?php echo e($id); ?>">
    <?php
} else {
    foreach ($gk as $gks) {
    ?>
        <!-- post card -->
        <div class="post-card flex gap10 " id="gkd<?php echo e($gks->id); ?>">
            <!-- post-image -->
            <?php
            if ($gks->image != "") {
            ?>
                <div class="post-img">
                    <img src="<?php echo e($gks->image); ?>" alt="">
                </div>

            <?php
            }
            ?>
            <!-- cancel -->
            <?php
            if ($gks->teacher_id == Session()->get('user_id') && Session()->get('role') == 'teacher') {
            ?>
                <div class="cancel" onclick="deleteCate('<?php echo e($gks->id); ?>')">
                    <img src="images/cancel-red.svg" alt="">
                </div>
            <?php
            }
            ?>
            <!-- post-content -->
            <div class="content flex-colomn gap10">
                <h3><?php echo e($gks->tittle); ?></h3>
                <div class="flex-colomn">
                    <div class="flex gap10 align-center">
                        <?php
                        if (Session()->get('role') == 'student' && Session()->get('user_id') == $gks->student_id) {
                        ?>
                            <span class="tag">For you</span>
                        <?php
                        }
                        ?>
                        <span class="tag"><?php echo e($gks->category); ?></span>
                    </div>
                    <span>Posted at: <?php echo e($gks->dt); ?></span>
                </div>
                <p class="p-primary expand" id="desc<?php echo e($gks->id); ?>"><?php echo e($gks->disc); ?></p>
                <span class="read-more width100" id="gk<?php echo e($gks->id); ?>" onclick="readmore('gk<?php echo e($gks->id); ?>','desc<?php echo e($gks->id); ?>')">Read more</span>
            </div>
        </div>
<?php
    }
}
?><?php /**PATH E:\laravel\trusher\resources\views/gkloader.blade.php ENDPATH**/ ?>