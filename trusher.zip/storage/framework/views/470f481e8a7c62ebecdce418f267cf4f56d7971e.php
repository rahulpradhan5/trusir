
<table >
    <tr>
        <td><?php echo e($name); ?></td>
        <td><?php echo e($email); ?></td>
        <td><?php echo e($content); ?></td>
    </tr>
</table><?php /**PATH E:\laravel\trusher\resources\views/mail.blade.php ENDPATH**/ ?>