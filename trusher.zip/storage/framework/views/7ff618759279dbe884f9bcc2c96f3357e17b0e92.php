
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex" style="justify-content:space-between;align-items:center;margin-bottom:1rem;">
        <h3>Student Info</h3>

    </div>
    <div class="row">
        <div style="display:flex;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;flex-direction: row;">
                <img src="../<?php echo e($student[0]->image); ?>" class="card-img-top" alt="..." style="height: 250px;width:30%">
                <div class="card-body" style="padding: 10px 30px;">
                    <p><span style="font-weight: bolder;font-size:medium;">Name:</span> <?php echo e($student[0]->name); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Father Name:</span> <?php echo e($student[0]->father_name); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Mother Name:</span> <?php echo e($student[0]->mother_name); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Phone:</span> +<?php echo e($student[0]->phone); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Gender:</span> <?php echo e($student[0]->gender); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Age:</span> <?php echo e($student[0]->age); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Paid:</span> <?php echo e($student[0]->paid); ?></p>
                </div>
            </div>
        </div>
        <!-- activator -->
        <div class="flex align-center card " style="padding-top:10px;background-color:white;border-radius:10px;display: flex;">
            <div class="adjuster" style="display: flex;align-items:center;gap:30px;font-weight:bold;">
                <p class="p-active" style="color: black;cursor:pointer;font-size:18px" id="address-p" onclick="shower('.card-div','#address','#address-p')">Address Info</p>
                <p style="color: black;cursor:pointer;font-size:18px" id="study-p" onclick="shower('.card-div','#study','#study-p')">Study info</p>
                <p style="color: black;cursor:pointer;font-size:18px" id="teacher-p" onclick="shower('.card-div','#teacherAssigned','#teacher-p')">Teacher Assigned</p>
                <p style="color: black;cursor:pointer;font-size:18px" id="course-p" onclick="shower('.card-div','#coursePur','#course-p')">Course Purchased</p>
                <p style="color: black;cursor:pointer;font-size:18px" id="test-p" onclick="shower('.card-div','#tests','#test-p')">Test Info</p>
                <p style="color: black;cursor:pointer;font-size:18px" id="progress-p" onclick="shower('.card-div','#progress','#progress-p')">Progress info</p>
            </div>
        </div>
        <!-- address assigned -->
        <div class="card-div" id="address" style="display:flex;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <h4>Addresss</h4>
                <div class="card-body" style="padding: 10px 30px;">
                    <p><span style="font-weight: bolder;font-size:medium;">Area:</span> <?php echo e($student[0]->area); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Pincode:</span> <?php echo e($student[0]->pincode); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">City:</span> <?php echo e($student[0]->city); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">State:</span> <?php echo e($student[0]->state); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">Full address:</span> <?php echo e($student[0]->current_full_address); ?></p>
                </div>
            </div>
        </div>
        <!-- study info -->
        <div class="card-div" id="study" style="display:none;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <h4>Study info</h4>
                <div class="card-body" style="padding: 10px 30px;">
                    <p><span style="font-weight: bolder;font-size:medium;">Class</span> <?php echo e($student[0]->class); ?>th</p>
                    <p><span style="font-weight: bolder;font-size:medium;">Medium:</span> <?php echo e($student[0]->medium); ?></p>
                    <p><span style="font-weight: bolder;font-size:medium;">School:</span> <?php echo e($student[0]->school_name); ?></p>

                </div>
            </div>
        </div>
        <!-- teacher assigned -->
        <div class="card-div" id="teacherAssigned" style="display:none;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <div class="d-flex" style="align-items:center;justify-content:space-between;">
                    <h4>Teacher Assigned</h4>
                </div>
                <div class="card-body" style="padding: 10px 30px;display:flex;align-items:center;gap:30px;justify-content:flex-start;flex-wrap:wrap;">
                    <?php
                    foreach ($teachers as $teacher) {
                    ?>
                        <div class="card" id="teacherassign<?php echo e($teacher->id); ?>" style="width: 30%;">
                            <img src="../<?php echo e($teacher->image); ?>" class="card-img-top" alt="..." style="height: 250px;">
                            <div class="card-body">
                                <div class="d-flex" style="justify-content:space-between;align-items:center;">
                                    <h5 class="card-title"><?php echo e($teacher->name); ?></h5>
                                    <p class="card-text">Subject:<?php echo e($teacher->course_name); ?></p>
                                </div>
                                <p class="card-text">Attendance:<?php echo e(collect($teacher->attandance)->where('techer_attend', 'yes')->count()); ?></p>
                                <p class="card-text">Absent:<?php echo e(collect($teacher->attandance)->where('techer_attend', 'no')->count()); ?></p>
                                <p class="card-text">Class:<?php echo e($student[0]->class); ?></p>
                                <div class="d-flex" style="justify-content: flex-end;align-items:center;gap:10px;">
                                    <a class="btn btn-danger" onclick="deleteteacher('<?php echo e($teacher->id); ?>')">Delete</a>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- course purchased -->
        <div class="card-div" id="coursePur" style="display:none;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <div class="d-flex" style="align-items:center;justify-content:space-between;">
                    <h4>Course Purchased</h4>
                    <a href="/admin/purchase-course?id=<?php echo e($_GET['id']); ?>"><button class="btn btn-primary">Add</button></a>
                </div>
                <div class="card-body" style="padding: 10px 30px;display:flex;align-items:center;gap:30px;justify-content:flex-start;flex-wrap:wrap;">
                    <?php
                    foreach ($courses as $course) {
                    ?>
                        <div class="card" style="max-width: 280px;" id="course<?php echo e($course->id); ?>">
                            <img src="../<?php echo e($course->image); ?>" class="card-img-top" alt="..." style="height: 250px;">
                            <div class="card-body">
                                <div class="d-flex" style="justify-content:space-between;align-items:center;">
                                    <h5 class="card-title"><?php echo e($course->course_name); ?></h5>
                                    <p class="card-text">Price:₹<?php echo e($course->price); ?></p>
                                </div>
                                <p class="card-text">Subject:<?php echo e($course->subject); ?></p>
                                <p class="card-text">Type:<?php echo e($course->type); ?></p>
                                <p class="card-text">Class:<?php echo e($student[0]->class); ?>th</p>
                                <p class="card-text">Purchase Date:<?php echo e($course->dt); ?></p>
                                <div class="d-flex" style="justify-content: flex-end;align-items:center;gap:10px;">
                                    <?php
                                    if ($course->teach_assign == null) {
                                    ?>
                                        <a href="/admin/assign?id=<?php echo e($_GET['id']); ?>&course_id=<?php echo e($course->id); ?>" class="btn btn-primary">Assign</a>

                                    <?php
                                    } else {
                                    ?>
                                        <a class="btn btn-primary">Assigned</a>
                                    <?php
                                    }
                                    ?>
                                    <a class="btn btn-danger" onclick="deleteCourse('<?php echo e($course->id); ?>')">Delete</a>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- Test info -->
        <div class="card-div" id="tests" style="display:none;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <div class="d-flex" style="align-items:center;justify-content:space-between;">
                    <h4>Test Info</h4>
                </div>
                <div class="card-body" style="padding: 10px 30px;display:flex;align-items:center;gap:30px;justify-content:flex-start;flex-wrap:wrap;">
                    <?php
                    foreach ($tests as $test) {
                    ?>
                        <div class="card" id="test<?php echo e($test->id); ?>" style="width: 40%;">
                            <div class="card-body">
                                <div class="d-flex" style="justify-content:space-between;align-items:center;">
                                    <h5 class="card-title"><?php echo e($test->title); ?></h5>

                                </div>
                                <p>Course: <?php echo e($test->course_name); ?></p>
                                <p>Posted on: <?php echo e($test->dt); ?></p>

                                <div class="d-flex" style="justify-content: flex-end;align-items:center;gap:10px;">
                                    <a href="../<?php echo e($test->questions); ?>" class="btn btn-primary" download>Questions</a>
                                    <a href="../<?php echo e($test->answer); ?>" class="btn btn-primary" download>Answers</a>
                                    <a class="btn btn-danger" onclick="deletest('<?php echo e($test->id); ?>')">Delete</a>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- progress report -->
        <div class="card-div" id="progress" style="display:none;justify-content:flex-start;align-items:center;gap:30px;flex-wrap:wrap;">
            <div class="card " style="width: 100%;display:flex;padding:10px">
                <div class="d-flex" style="align-items:center;justify-content:space-between;">
                    <h4>Progress report</h4>
                    <a href="/admin/add-progress?id=<?php echo e($_GET['id']); ?>"><button class="btn btn-primary ">Add</button></a>
                </div>
                <div class="card-body" style="padding: 10px 30px;display:flex;align-items:center;gap:30px;justify-content:flex-start;flex-wrap:wrap;">
                    <?php
                    foreach ($progress as $test) {
                    ?>
                        <div class="card" id="progress<?php echo e($test->id); ?>" style="width: 40%;">
                            <div class="card-body">
                                <div class="d-flex" style="justify-content:space-between;align-items:center;">
                                    <h5 class="card-title"><?php echo e($test->dt); ?></h5>

                                </div>
                                <p>Course: <?php echo e($test->course_name); ?></p>
                                <p>Marks: <?php echo e($test->obtain_marks); ?>/<?php echo e($test->total_marks); ?></p>

                                <div class="d-flex" style="justify-content: flex-end;align-items:center;gap:10px;">
                                    <a href="../<?php echo e($test->file); ?>" class="btn btn-primary" download>Download</a>
                                    <a class="btn btn-danger" onclick="deletest('<?php echo e($test->id); ?>')">Delete</a>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function deleteteacher(id) {
        $.ajax({
            url: "/admin/deletedeleteteacherassign",
            data: {
                id: id
            },
            type: 'get',
            success: function(data) {
                if (data == "success") {
                    alert("Teacher deleted successfully");
                    $("#teacherassign" + id).remove();
                } else {
                    alert(data);
                }
            }
        })
    }

    function deletest(id) {
        $.ajax({
            url: "/admin/deletetest",
            data: {
                id: id
            },
            type: 'get',
            success: function(data) {
                if (data == "success") {
                    alert("Test deleted successfully");
                    $("#test" + id).remove();
                } else {
                    alert(data);
                }
            }
        })
    }

    function deletprogress(id) {
        $.ajax({
            url: "/admin/deleteprogress",
            data: {
                id: id
            },
            type: 'get',
            success: function(data) {
                if (data == "success") {
                    alert("Progress deleted successfully");
                    $("#progress" + id).remove();
                } else {
                    alert(data);
                }
            }
        })
    }

    function deleteCourse(id) {
        $.ajax({
            url: "/admin/deletecoursepurchased",
            data: {
                id: id
            },
            type: 'get',
            success: function(data) {
                if (data == "success") {
                    alert("Course deleted successfully");
                    $("#course" + id).remove();
                } else {
                    alert(data);
                }
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\trusher\resources\views/admin/student/view-student.blade.php ENDPATH**/ ?>