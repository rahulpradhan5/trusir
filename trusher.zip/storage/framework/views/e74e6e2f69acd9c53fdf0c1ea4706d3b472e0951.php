
<?php $__env->startSection('content'); ?>

<!-- all teacher -->
<div class="teachers margin-t30">
    <div class="section">
        <?php
        if (Session()->get("role") == "student") {
        ?>
            <div class="heading">
                <img src="images/star.svg" alt="">
                Teacher assigned
            </div>
        <?php
        } else if (Session()->get("role") == "teacher") {
        ?>
            <div class="heading">
                <img src="images/star.svg" alt="">
                Students
            </div>
        <?php
        }
        ?>
        <div class="post-row flex align-center gap30 flex-wrap margin-t30">
            <?php
            if ($teachers->count() > 0) {
                foreach ($teachers as $teacher) {
                    if (Session()->get("role") == "student") {
            ?>
                        <!-- teacher profile -->
                        <a href="EditTeacher_Profile?id=<?php echo $teacher->id; ?>" style="text-decoration: none;">
                            <div class="teacher-profile-card flex-colomn">
                                <div class="profile-card-img">
                                    <img src="<?php echo e($teacher->image); ?>" alt="">
                                </div>
                                <div class="content flex-colomn ">
                                    <div>
                                        <h3><?php echo e($teacher->name); ?></h3>
                                        <p class="tag"><?php echo e($teacher->subject); ?></p>
                                    </div>
                                   <p>Assign date: <?php echo e($teacher->dt); ?></p>

                                </div>
                            </div>
                        </a>
                    <?php
                    } else {
                    ?>
                        <!-- teacher profile -->
                        <a href="My_Profile?id=<?php echo $teacher->id; ?>" style="text-decoration: none;">
                            <div class="teacher-profile-card flex-colomn">
                                <div class="profile-card-img">
                                    <img src="<?php echo e($teacher->image); ?>" alt="">
                                </div>
                                <div class="content flex-colomn ">
                                    <div>
                                        <h3><?php echo e($teacher->name); ?></h3>
                                        <div class="flex align-center gap10">
                                            <p class="tag"><?php echo e($teacher->subject); ?></p>
                                            <p class="tag"><?php echo e($teacher->type); ?></p>
                                        </div>

                                    </div>
                                    <p>Class: <?php echo e($teacher->class); ?></p>
                                    <p>Joining date: <?php echo e($teacher->dt); ?></p>
                                </div>
                            </div>
                        </a>
                <?php
                    }
                }
            } else {
                ?>
                <div class="heading">
                    No data found
                </div>
            <?php
            }
            ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\trusher\resources\views/Teacher_Profile.blade.php ENDPATH**/ ?>